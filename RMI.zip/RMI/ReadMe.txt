Remote Method Invocation, using java implementation
1. AddI remote interface created
2. AddC implemented remote interface AddI
3. Start rmiregistry
	i. type to the cmd the following command to start rmiregistry
	   < start rmiregistry >
4. create and start server
	 i. create server cmd, go to the RMI directory 
            If javac is not recognized, use this command 
            < set path="c:\Program Files\Java\jdk1.8.0_121\bin" >
	ii. compile all the java files using cmd 
       	    < javac *.java >
	    four java classes are going to be created
	iii. to create stub for the client , use the following command
	     < rmic AddC >
	     AddC_Stub.class will be created
	     we can not see the skeleton, because it is on the server side
	iv. to start the server use the command
	    < java Server > 
5. create and start client
	i. create client cmd, go to the RMI directory 
           If javac is not recognized, use this command 
           < set path="c:\Program Files\Java\jdk1.8.0_121\bin" >
	ii. to start the client use the command
            < java Client>
            this will result the addition of the provided inputs.



