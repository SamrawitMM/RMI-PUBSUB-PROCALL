import java.rmi.*;
// run independently (so has it's own main method)
public class Client{
    public static void main(String a[]) throws Exception{
    	// we don't know where AddC is, so client will ask
    	// the rmi registry to lookup for the catption name ADD
    	// we require object of interface so use type casting 
        AddI obj = (AddI)Naming.lookup("ADD");
        int n = obj.add(5, 4);
        System.out.println("addition is : " + n);
    }
}