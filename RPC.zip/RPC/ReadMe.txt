TERMINAL cd RPC/
rpcgen -a -C add.x  necessary files will be created
make -f Makefile.add

sudo./add_server
open another terminal for client
start the client
sudo ./add_client localhost


sudo ./add_server
make -f Makefile.add
sudo ./add_server

open client side sudo ./add_client localhost  10 20





add_server file -> printf("add(%d, %d) is called \n",  arg->a, argp->b);
result  = argp->a + argp->b;

add_client file -> printf NUMBER NUMBER
void add_prog_1(char *host, int x, int y)
after #endif -> add_1_arg.a=x;
		add_1_arg.b=y;
after if -> else{
		printf("Result: %d\n", *result_1);
	}
add_prog_1 (host, atoi(argv[2]), atoi(  argv[3));


 
